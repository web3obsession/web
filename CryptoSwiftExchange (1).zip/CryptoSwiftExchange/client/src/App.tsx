import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/layout/navbar";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Trading from "@/pages/trading";
import QuickSwap from "@/pages/quick-swap";
import Portfolio from "@/pages/portfolio";
import Wallet from "@/pages/wallet";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-crypto-dark text-white font-inter">
      <Navbar />
      <Switch>
        {isLoading || !isAuthenticated ? (
          <>
            <Route path="/" component={Landing} />
            <Route path="/quick-swap" component={QuickSwap} />
          </>
        ) : (
          <>
            <Route path="/" component={Dashboard} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/trading" component={Trading} />
            <Route path="/portfolio" component={Portfolio} />
            <Route path="/wallet" component={Wallet} />
          </>
        )}
        {/* Quick swap is always available */}
        <Route path="/quick-swap" component={QuickSwap} />
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
