import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export default function Navbar() {
  const { isAuthenticated, user, isLoading } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", authRequired: true },
    { href: "/trading", label: "Trading", authRequired: true },
    { href: "/quick-swap", label: "Quick Swap", authRequired: false },
    { href: "/portfolio", label: "Portfolio", authRequired: true },
    { href: "/wallet", label: "Wallet", authRequired: true },
  ];

  const getActiveClass = (href: string) => {
    const isActive = location === href || (href === "/" && location === "/dashboard");
    return isActive
      ? "text-crypto-accent border-b-2 border-crypto-accent pb-1"
      : "text-crypto-gray hover:text-white";
  };

  return (
    <nav className="bg-crypto-secondary border-b border-crypto-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-8">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <div className="w-8 h-8 bg-gradient-to-r from-crypto-accent to-purple-500 rounded-lg flex items-center justify-center">
                <i className="fas fa-cube text-white text-sm"></i>
              </div>
              <span className="text-xl font-bold">CryptoVault</span>
            </div>
          </Link>
          
          {/* Navigation Items */}
          <div className="hidden md:flex space-x-6">
            {navItems.map((item) => {
              if (item.authRequired && (!isAuthenticated && !isLoading)) {
                return null;
              }
              
              return (
                <Link key={item.href} href={item.href}>
                  <button className={`nav-btn ${getActiveClass(item.href)} transition-colors`}>
                    {item.label}
                  </button>
                </Link>
              );
            })}
          </div>
        </div>
        
        {/* Auth Section */}
        <div className="flex items-center space-x-4">
          {isLoading ? (
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-crypto-accent"></div>
          ) : isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                {user?.profileImageUrl && (
                  <img 
                    src={user.profileImageUrl} 
                    alt="User avatar" 
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="hidden sm:block">
                  {user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : user?.email}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                className="text-crypto-gray hover:text-white"
                onClick={() => window.location.href = "/api/logout"}
              >
                <i className="fas fa-sign-out-alt"></i>
              </Button>
            </div>
          ) : (
            <div className="flex space-x-2">
              <Button 
                className="bg-crypto-accent hover:bg-blue-600"
                onClick={() => window.location.href = "/api/login"}
              >
                Login
              </Button>
              <Button 
                variant="outline" 
                className="border-crypto-border hover:border-crypto-accent"
                onClick={() => window.location.href = "/api/login"}
              >
                Register
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <div className="md:hidden mt-4 flex flex-wrap gap-4">
        {navItems.map((item) => {
          if (item.authRequired && (!isAuthenticated && !isLoading)) {
            return null;
          }
          
          return (
            <Link key={item.href} href={item.href}>
              <button className={`nav-btn ${getActiveClass(item.href)} text-sm transition-colors`}>
                {item.label}
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
