import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface OrderBookProps {
  orderBook?: {
    bids: Array<{
      id: number;
      price: string;
      amount: string;
      type: string;
    }>;
    asks: Array<{
      id: number;
      price: string;
      amount: string;
      type: string;
    }>;
  };
  currentPair?: {
    id: number;
    symbol: string;
    baseCrypto: { symbol: string };
    quoteCrypto: { symbol: string };
  };
  tradingPairs?: Array<{
    id: number;
    symbol: string;
    baseCrypto: { symbol: string };
    quoteCrypto: { symbol: string };
  }>;
  selectedPair: number;
  onPairChange: (pairId: number) => void;
  isLoading: boolean;
}

export default function OrderBook({ 
  orderBook, 
  currentPair, 
  tradingPairs, 
  selectedPair, 
  onPairChange, 
  isLoading 
}: OrderBookProps) {
  const currentPrice = orderBook?.bids?.[0]?.price || orderBook?.asks?.[0]?.price || "0";

  return (
    <Card className="bg-crypto-secondary border-crypto-border h-full">
      <CardContent className="p-0">
        <div className="p-4 border-b border-crypto-border">
          <h3 className="font-semibold mb-3">Order Book</h3>
          <Select 
            value={selectedPair.toString()} 
            onValueChange={(value) => onPairChange(parseInt(value))}
          >
            <SelectTrigger className="bg-crypto-dark border-crypto-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {tradingPairs?.map((pair) => (
                <SelectItem key={pair.id} value={pair.id.toString()}>
                  {pair.symbol}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="p-4">
          {/* Asks (Sell Orders) */}
          <div className="mb-4">
            <div className="flex justify-between text-xs text-crypto-gray mb-2">
              <span>Price ({currentPair?.quoteCrypto.symbol || "USDT"})</span>
              <span>Amount ({currentPair?.baseCrypto.symbol || "BTC"})</span>
              <span>Total</span>
            </div>
            
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <div key={i} className="flex justify-between text-xs py-1">
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-3 w-16" />
                </div>
              ))
            ) : (
              orderBook?.asks?.slice(0, 8).reverse().map((order, index) => {
                const total = (parseFloat(order.price) * parseFloat(order.amount)).toFixed(2);
                return (
                  <div key={order.id || index} className="flex justify-between text-xs py-1 hover:bg-crypto-red/10 cursor-pointer">
                    <span className="text-crypto-red">{parseFloat(order.price).toFixed(2)}</span>
                    <span>{parseFloat(order.amount).toFixed(8)}</span>
                    <span className="text-crypto-gray">{total}</span>
                  </div>
                );
              })
            )}
          </div>

          {/* Current Price */}
          <div className="text-center py-3 border-y border-crypto-border mb-4">
            {isLoading ? (
              <Skeleton className="h-6 w-24 mx-auto" />
            ) : (
              <>
                <div className="text-lg font-bold text-crypto-green">
                  {parseFloat(currentPrice).toFixed(2)}
                </div>
                <div className="text-xs text-crypto-gray">
                  ≈ ${parseFloat(currentPrice).toFixed(2)}
                </div>
              </>
            )}
          </div>

          {/* Bids (Buy Orders) */}
          <div>
            <div className="flex justify-between text-xs text-crypto-gray mb-2">
              <span>Price ({currentPair?.quoteCrypto.symbol || "USDT"})</span>
              <span>Amount ({currentPair?.baseCrypto.symbol || "BTC"})</span>
              <span>Total</span>
            </div>
            
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <div key={i} className="flex justify-between text-xs py-1">
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-3 w-16" />
                </div>
              ))
            ) : (
              orderBook?.bids?.slice(0, 8).map((order, index) => {
                const total = (parseFloat(order.price) * parseFloat(order.amount)).toFixed(2);
                return (
                  <div key={order.id || index} className="flex justify-between text-xs py-1 hover:bg-crypto-green/10 cursor-pointer">
                    <span className="text-crypto-green">{parseFloat(order.price).toFixed(2)}</span>
                    <span>{parseFloat(order.amount).toFixed(8)}</span>
                    <span className="text-crypto-gray">{total}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
