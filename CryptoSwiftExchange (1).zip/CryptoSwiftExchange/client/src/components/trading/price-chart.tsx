import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface PriceChartProps {
  currentPair?: {
    id: number;
    symbol: string;
    baseCrypto: { symbol: string };
    quoteCrypto: { symbol: string };
  };
  priceHistory?: Array<{
    id: number;
    price: string;
    volume: string;
    timestamp: string;
  }>;
  isLoading: boolean;
}

export default function PriceChart({ currentPair, priceHistory, isLoading }: PriceChartProps) {
  const [timeframe, setTimeframe] = useState("1D");
  
  const currentPrice = priceHistory?.[priceHistory.length - 1]?.price || "0";
  const previousPrice = priceHistory?.[priceHistory.length - 2]?.price || currentPrice;
  const priceChange = parseFloat(currentPrice) - parseFloat(previousPrice);
  const priceChangePercent = (priceChange / parseFloat(previousPrice)) * 100;

  const timeframes = ["1H", "1D", "1W", "1M", "1Y"];

  return (
    <Card className="bg-crypto-secondary border-crypto-border h-full">
      <CardContent className="p-0">
        <div className="p-4 border-b border-crypto-border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{currentPair?.symbol || "BTC/USDT"}</h3>
              <div className="flex items-center space-x-4 text-sm mt-1">
                {isLoading ? (
                  <>
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-20" />
                  </>
                ) : (
                  <>
                    <span className="text-crypto-green text-lg font-bold">
                      {parseFloat(currentPrice).toFixed(2)}
                    </span>
                    <span className={`${priceChange >= 0 ? "text-crypto-green" : "text-crypto-red"}`}>
                      {priceChange >= 0 ? "+" : ""}{priceChange.toFixed(2)} ({priceChange >= 0 ? "+" : ""}{priceChangePercent.toFixed(2)}%)
                    </span>
                  </>
                )}
              </div>
            </div>
            <div className="flex space-x-2">
              {timeframes.map((tf) => (
                <Button
                  key={tf}
                  variant={timeframe === tf ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setTimeframe(tf)}
                  className={`px-3 py-1 text-xs ${
                    timeframe === tf 
                      ? "bg-crypto-accent" 
                      : "text-crypto-gray hover:text-white"
                  }`}
                >
                  {tf}
                </Button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Chart Area */}
        <div className="chart-container h-96 p-4 flex items-center justify-center">
          {isLoading ? (
            <div className="space-y-4 w-full">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
            </div>
          ) : (
            <div className="text-center">
              <i className="fas fa-chart-line text-4xl text-crypto-gray mb-4"></i>
              <p className="text-crypto-gray">Interactive Price Chart</p>
              <p className="text-sm text-crypto-gray mt-2">
                Chart integration with TradingView or Chart.js would be implemented here
              </p>
              {priceHistory && priceHistory.length > 0 && (
                <div className="mt-4 text-sm">
                  <p className="text-crypto-gray">
                    Latest Price: <span className="text-white">${parseFloat(currentPrice).toFixed(2)}</span>
                  </p>
                  <p className="text-crypto-gray">
                    Data Points: <span className="text-white">{priceHistory.length}</span>
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
