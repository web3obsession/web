import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

interface TradingPanelProps {
  currentPair?: {
    id: number;
    symbol: string;
    baseCrypto: { symbol: string };
    quoteCrypto: { symbol: string };
  };
  userOrders?: Array<{
    id: number;
    type: string;
    amount: string;
    price: string;
    status: string;
    pair: {
      symbol: string;
    };
  }>;
  onOrderPlaced: () => void;
  isLoading: boolean;
}

export default function TradingPanel({ currentPair, userOrders, onOrderPlaced, isLoading }: TradingPanelProps) {
  const { toast } = useToast();
  const [orderType, setOrderType] = useState("market");
  const [amount, setAmount] = useState("");
  const [price, setPrice] = useState("");
  const [side, setSide] = useState<"buy" | "sell">("buy");

  const placeOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order Placed",
        description: "Your order has been placed successfully.",
      });
      setAmount("");
      setPrice("");
      onOrderPlaced();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Order Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const cancelOrderMutation = useMutation({
    mutationFn: async (orderId: number) => {
      const response = await apiRequest("DELETE", `/api/orders/${orderId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order Cancelled",
        description: "Your order has been cancelled successfully.",
      });
      onOrderPlaced(); // Refresh orders
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Cancel Error",
        description: "Failed to cancel order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePlaceOrder = () => {
    if (!currentPair || !amount) {
      toast({
        title: "Invalid Order",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (orderType === "limit" && !price) {
      toast({
        title: "Invalid Order",
        description: "Price is required for limit orders.",
        variant: "destructive",
      });
      return;
    }

    placeOrderMutation.mutate({
      pairId: currentPair.id,
      type: side,
      orderType,
      amount,
      price: orderType === "limit" ? price : null,
    });
  };

  const calculateTotal = () => {
    if (!amount || !price) return "0.00";
    return (parseFloat(amount) * parseFloat(price)).toFixed(2);
  };

  const activeOrders = userOrders?.filter(order => order.status === "active") || [];

  return (
    <Card className="bg-crypto-secondary border-crypto-border h-full">
      <CardContent className="p-0">
        <Tabs value={side} onValueChange={(value) => setSide(value as "buy" | "sell")} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-crypto-dark">
            <TabsTrigger 
              value="buy" 
              className="data-[state=active]:bg-crypto-green data-[state=active]:text-white"
            >
              Buy
            </TabsTrigger>
            <TabsTrigger 
              value="sell" 
              className="data-[state=active]:bg-crypto-red data-[state=active]:text-white"
            >
              Sell
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="buy" className="p-4 space-y-4">
            <div>
              <Label className="text-sm text-crypto-gray mb-1">Order Type</Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger className="bg-crypto-dark border-crypto-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="market">Market</SelectItem>
                  <SelectItem value="limit">Limit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm text-crypto-gray mb-1">
                Amount ({currentPair?.baseCrypto.symbol || "BTC"})
              </Label>
              <Input
                type="number"
                placeholder="0.00000000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-crypto-dark border-crypto-border"
              />
            </div>
            
            {orderType === "limit" && (
              <div>
                <Label className="text-sm text-crypto-gray mb-1">
                  Price ({currentPair?.quoteCrypto.symbol || "USDT"})
                </Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="bg-crypto-dark border-crypto-border"
                />
              </div>
            )}
            
            <div>
              <Label className="text-sm text-crypto-gray mb-1">
                Total ({currentPair?.quoteCrypto.symbol || "USDT"})
              </Label>
              <Input
                type="number"
                placeholder="0.00"
                value={orderType === "limit" ? calculateTotal() : "Market Price"}
                readOnly
                className="bg-crypto-dark border-crypto-border"
              />
            </div>
            
            <div className="flex justify-between text-sm text-crypto-gray">
              <span>Available:</span>
              <span>12,456.78 {currentPair?.quoteCrypto.symbol || "USDT"}</span>
            </div>
            
            <Button 
              onClick={handlePlaceOrder}
              disabled={placeOrderMutation.isPending || !amount}
              className="w-full bg-crypto-green hover:bg-green-600"
            >
              {placeOrderMutation.isPending ? "Placing..." : `Buy ${currentPair?.baseCrypto.symbol || "BTC"}`}
            </Button>
          </TabsContent>
          
          <TabsContent value="sell" className="p-4 space-y-4">
            <div>
              <Label className="text-sm text-crypto-gray mb-1">Order Type</Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger className="bg-crypto-dark border-crypto-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="market">Market</SelectItem>
                  <SelectItem value="limit">Limit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm text-crypto-gray mb-1">
                Amount ({currentPair?.baseCrypto.symbol || "BTC"})
              </Label>
              <Input
                type="number"
                placeholder="0.00000000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-crypto-dark border-crypto-border"
              />
            </div>
            
            {orderType === "limit" && (
              <div>
                <Label className="text-sm text-crypto-gray mb-1">
                  Price ({currentPair?.quoteCrypto.symbol || "USDT"})
                </Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="bg-crypto-dark border-crypto-border"
                />
              </div>
            )}
            
            <div>
              <Label className="text-sm text-crypto-gray mb-1">
                Total ({currentPair?.quoteCrypto.symbol || "USDT"})
              </Label>
              <Input
                type="number"
                placeholder="0.00"
                value={orderType === "limit" ? calculateTotal() : "Market Price"}
                readOnly
                className="bg-crypto-dark border-crypto-border"
              />
            </div>
            
            <div className="flex justify-between text-sm text-crypto-gray">
              <span>Available:</span>
              <span>1.24567890 {currentPair?.baseCrypto.symbol || "BTC"}</span>
            </div>
            
            <Button 
              onClick={handlePlaceOrder}
              disabled={placeOrderMutation.isPending || !amount}
              className="w-full bg-crypto-red hover:bg-red-600"
            >
              {placeOrderMutation.isPending ? "Placing..." : `Sell ${currentPair?.baseCrypto.symbol || "BTC"}`}
            </Button>
          </TabsContent>
        </Tabs>
        
        {/* Open Orders Section */}
        <div className="border-t border-crypto-border p-4">
          <h4 className="font-medium mb-3">Open Orders</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {isLoading ? (
              [...Array(2)].map((_, i) => (
                <div key={i} className="flex justify-between items-center py-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                </div>
              ))
            ) : activeOrders.length > 0 ? (
              activeOrders.map((order) => (
                <div key={order.id} className="flex justify-between items-center py-2 border-t border-crypto-border">
                  <div className="text-sm">
                    <span className={order.type === "buy" ? "text-crypto-green" : "text-crypto-red"}>
                      {order.type.toUpperCase()}
                    </span>{" "}
                    {parseFloat(order.amount).toFixed(8)} {currentPair?.baseCrypto.symbol}
                    {order.price && (
                      <div className="text-xs text-crypto-gray">
                        @ {parseFloat(order.price).toFixed(2)}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => cancelOrderMutation.mutate(order.id)}
                    disabled={cancelOrderMutation.isPending}
                    className="text-crypto-red hover:text-red-400 text-xs h-auto p-1"
                  >
                    Cancel
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-sm text-crypto-gray text-center py-4">No open orders</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
