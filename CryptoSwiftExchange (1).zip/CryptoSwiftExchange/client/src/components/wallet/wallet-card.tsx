import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface WalletCardProps {
  wallet: {
    id: number;
    balance: string;
    address: string;
    cryptocurrency: {
      symbol: string;
      name: string;
      network: string;
    };
  };
  onCopyAddress: (address: string) => void;
}

export default function WalletCard({ wallet, onCopyAddress }: WalletCardProps) {
  const { cryptocurrency, balance, address } = wallet;
  const symbol = cryptocurrency.symbol;
  
  // Mock USD values - in production would use real market prices
  const usdValue = parseFloat(balance) * (
    symbol === "BTC" ? 43122.45 : 
    symbol === "ETH" ? 1905.67 :
    symbol === "BASE" ? 17.25 : 1
  );

  const getIcon = () => {
    switch (symbol) {
      case "BTC":
        return <i className="fab fa-bitcoin text-white"></i>;
      case "ETH":
        return <i className="fab fa-ethereum text-white"></i>;
      case "BASE":
        return <span className="text-white font-bold">B</span>;
      default:
        return <span className="text-white font-bold">{symbol[0]}</span>;
    }
  };

  const getIconColor = () => {
    switch (symbol) {
      case "BTC":
        return "bg-orange-500";
      case "ETH":
        return "bg-blue-500";
      case "BASE":
        return "bg-blue-600";
      default:
        return "bg-green-500";
    }
  };

  return (
    <Card className="bg-crypto-secondary border-crypto-border">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className={`w-12 h-12 ${getIconColor()} rounded-full flex items-center justify-center`}>
            {getIcon()}
          </div>
          <div>
            <h3 className="font-semibold">{cryptocurrency.name}</h3>
            <p className="text-sm text-crypto-gray">{cryptocurrency.network} Network</p>
          </div>
        </div>
        
        <p className="text-2xl font-bold mb-2">{parseFloat(balance).toFixed(8)}</p>
        <p className="text-crypto-gray text-sm mb-4">≈ ${usdValue.toFixed(2)}</p>
        
        <div className="space-y-3">
          <div className="bg-crypto-dark p-3 rounded-lg">
            <p className="text-xs text-crypto-gray mb-1">Deposit Address:</p>
            <div className="flex items-center justify-between">
              <code className="text-xs text-white break-all mr-2">
                {address.slice(0, 12)}...{address.slice(-8)}
              </code>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onCopyAddress(address)}
                className="text-crypto-accent hover:text-blue-400 h-auto p-1"
              >
                <i className="fas fa-copy"></i>
              </Button>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              className="flex-1 bg-crypto-accent hover:bg-blue-600 text-sm"
              size="sm"
            >
              Deposit
            </Button>
            <Button 
              variant="outline" 
              className="flex-1 border-crypto-border hover:border-crypto-accent text-sm"
              size="sm"
            >
              Withdraw
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
