import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: wallets, isLoading: walletsLoading } = useQuery({
    queryKey: ["/api/wallets"],
    enabled: isAuthenticated,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
    refetchInterval: 10000, // Refresh orders more frequently
  });

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-crypto-secondary border-crypto-border">
              <CardContent className="p-6">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-32 mb-2" />
                <Skeleton className="h-4 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Calculate portfolio stats
  const totalBalance = wallets?.reduce((sum, wallet) => {
    const balance = parseFloat(wallet.balance || "0");
    // Simple price calculation - in production would use real market prices
    const usdValue = balance * (wallet.cryptocurrency.symbol === "BTC" ? 43122.45 : 
                               wallet.cryptocurrency.symbol === "ETH" ? 1905.67 :
                               wallet.cryptocurrency.symbol === "BASE" ? 17.25 : 1);
    return sum + usdValue;
  }, 0) || 0;

  const activeOrdersCount = orders?.filter(order => order.status === "active").length || 0;

  const todayTransactions = transactions?.filter(tx => {
    const txDate = new Date(tx.createdAt || '');
    const today = new Date();
    return txDate.toDateString() === today.toDateString();
  }) || [];

  const todayVolume = todayTransactions.reduce((sum, tx) => {
    return sum + parseFloat(tx.amount || "0");
  }, 0);

  return (
    <div className="flex-1 p-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-crypto-gray text-sm">Total Balance</p>
                <p className="text-2xl font-bold">${totalBalance.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 bg-crypto-accent/20 rounded-xl flex items-center justify-center">
                <i className="fas fa-wallet text-crypto-accent"></i>
              </div>
            </div>
            <div className="flex items-center mt-2">
              <span className="text-crypto-green text-sm">+12.5%</span>
              <span className="text-crypto-gray text-sm ml-1">24h</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-crypto-gray text-sm">24h P&L</p>
                <p className="text-2xl font-bold text-crypto-green">+$1,247.89</p>
              </div>
              <div className="w-12 h-12 bg-crypto-green/20 rounded-xl flex items-center justify-center">
                <i className="fas fa-chart-line text-crypto-green"></i>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-crypto-gray text-sm">Active Orders</p>
                <p className="text-2xl font-bold">{activeOrdersCount}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                <i className="fas fa-list text-yellow-500"></i>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-crypto-gray text-sm">Today's Volume</p>
                <p className="text-2xl font-bold">${todayVolume.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <i className="fas fa-exchange-alt text-purple-500"></i>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Portfolio Overview & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Portfolio Breakdown */}
        <div className="lg:col-span-2">
          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Portfolio Breakdown</h3>
              <div className="space-y-4">
                {walletsLoading ? (
                  [...Array(3)].map((_, i) => (
                    <div key={i} className="flex items-center justify-between py-2">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="w-8 h-8 rounded-full" />
                        <div>
                          <Skeleton className="h-4 w-16 mb-1" />
                          <Skeleton className="h-3 w-20" />
                        </div>
                      </div>
                      <div className="text-right">
                        <Skeleton className="h-4 w-20 mb-1" />
                        <Skeleton className="h-3 w-12" />
                      </div>
                    </div>
                  ))
                ) : wallets && wallets.length > 0 ? (
                  wallets.map((wallet) => {
                    const balance = parseFloat(wallet.balance || "0");
                    const symbol = wallet.cryptocurrency.symbol;
                    const usdValue = balance * (symbol === "BTC" ? 43122.45 : 
                                               symbol === "ETH" ? 1905.67 :
                                               symbol === "BASE" ? 17.25 : 1);
                    const change = Math.random() > 0.5 ? "+" : "-";
                    const changePercent = (Math.random() * 10).toFixed(1);
                    
                    const iconColor = symbol === "BTC" ? "bg-orange-500" :
                                     symbol === "ETH" ? "bg-blue-500" :
                                     symbol === "BASE" ? "bg-blue-600" : "bg-green-500";
                    
                    const icon = symbol === "BTC" ? "₿" :
                                symbol === "ETH" ? "Ξ" :
                                symbol === "BASE" ? "B" : "T";

                    return (
                      <div key={wallet.id} className="flex items-center justify-between py-2">
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 ${iconColor} rounded-full flex items-center justify-center text-xs font-bold text-white`}>
                            {icon}
                          </div>
                          <div>
                            <p className="font-medium">{wallet.cryptocurrency.name}</p>
                            <p className="text-sm text-crypto-gray">{balance.toFixed(8)} {symbol}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">${usdValue.toFixed(2)}</p>
                          <p className={`text-sm ${change === "+" ? "text-crypto-green" : "text-crypto-red"}`}>
                            {change}{changePercent}%
                          </p>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-8">
                    <p className="text-crypto-gray">No wallets found. Create your first wallet to get started.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Button asChild className="w-full bg-crypto-accent hover:bg-blue-600">
                <Link href="/wallet">
                  <i className="fas fa-plus mr-2"></i>
                  Deposit Funds
                </Link>
              </Button>
              
              <Button asChild className="w-full bg-crypto-green hover:bg-green-600">
                <Link href="/quick-swap">
                  <i className="fas fa-exchange-alt mr-2"></i>
                  Quick Swap
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="w-full border-crypto-border hover:border-crypto-accent">
                <Link href="/wallet">
                  <i className="fas fa-minus mr-2"></i>
                  Withdraw
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="w-full border-crypto-border hover:border-crypto-accent">
                <Link href="/trading">
                  <i className="fas fa-chart-bar mr-2"></i>
                  Advanced Trading
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="bg-crypto-secondary border-crypto-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Transactions</h3>
            <Button asChild variant="ghost" size="sm" className="text-crypto-accent hover:text-blue-400">
              <Link href="/wallet">View All</Link>
            </Button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-crypto-gray text-sm">
                  <th className="text-left py-2">Type</th>
                  <th className="text-left py-2">Asset</th>
                  <th className="text-left py-2">Amount</th>
                  <th className="text-left py-2">Status</th>
                  <th className="text-left py-2">Time</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {transactionsLoading ? (
                  [...Array(3)].map((_, i) => (
                    <tr key={i} className="border-t border-crypto-border">
                      <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-12" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-20" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-20" /></td>
                    </tr>
                  ))
                ) : transactions && transactions.length > 0 ? (
                  transactions.slice(0, 5).map((tx) => {
                    const typeMap = {
                      1: { name: "Deposit", color: "bg-crypto-green/20 text-crypto-green" },
                      2: { name: "Withdraw", color: "bg-crypto-red/20 text-crypto-red" },
                      3: { name: "Trade", color: "bg-crypto-accent/20 text-crypto-accent" },
                      4: { name: "Swap", color: "bg-purple-500/20 text-purple-500" }
                    };
                    
                    const type = typeMap[tx.typeId as keyof typeof typeMap] || { name: "Unknown", color: "bg-gray-500/20 text-gray-500" };
                    
                    return (
                      <tr key={tx.id} className="border-t border-crypto-border">
                        <td className="py-3">
                          <span className={`px-2 py-1 rounded text-xs ${type.color}`}>
                            {type.name}
                          </span>
                        </td>
                        <td className="py-3">{tx.cryptocurrency.symbol}</td>
                        <td className="py-3">{parseFloat(tx.amount).toFixed(8)} {tx.cryptocurrency.symbol}</td>
                        <td className="py-3">
                          <span className={`${tx.status === "completed" ? "text-crypto-green" : 
                                            tx.status === "pending" ? "text-yellow-500" : "text-crypto-red"}`}>
                            {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-3 text-crypto-gray">
                          {new Date(tx.createdAt || '').toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-crypto-gray">
                      No transactions found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
