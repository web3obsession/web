import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-crypto-dark via-crypto-secondary to-crypto-dark">
      {/* Hero Section */}
      <div className="container mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-crypto-accent to-purple-500 rounded-xl flex items-center justify-center">
              <i className="fas fa-cube text-white text-xl"></i>
            </div>
            <span className="text-4xl font-bold">CryptoVault</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            Professional Crypto Trading
          </h1>
          
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Advanced cryptocurrency exchange with instant swaps, professional trading tools, and secure wallet management across Bitcoin, Ethereum, and Base networks.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              asChild 
              size="lg" 
              className="bg-crypto-accent hover:bg-blue-600 text-white px-8 py-4 text-lg"
            >
              <Link href="/api/login">
                Start Trading
              </Link>
            </Button>
            
            <Button 
              asChild 
              variant="outline" 
              size="lg" 
              className="border-crypto-accent text-crypto-accent hover:bg-crypto-accent hover:text-white px-8 py-4 text-lg"
            >
              <Link href="/quick-swap">
                Quick Swap (No Account)
              </Link>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-crypto-green/20 rounded-xl flex items-center justify-center mb-4">
                <i className="fas fa-exchange-alt text-crypto-green text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2">Instant Swaps</h3>
              <p className="text-gray-400 text-sm">
                Swap cryptocurrencies instantly without registration. Quick and anonymous trading.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-crypto-accent/20 rounded-xl flex items-center justify-center mb-4">
                <i className="fas fa-chart-line text-crypto-accent text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2">Advanced Trading</h3>
              <p className="text-gray-400 text-sm">
                Professional order book, real-time charts, and advanced order types for serious traders.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mb-4">
                <i className="fas fa-shield-alt text-purple-500 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2">Secure Wallets</h3>
              <p className="text-gray-400 text-sm">
                Auto-generated wallets for Bitcoin, Ethereum, and Base with institutional-grade security.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center mb-4">
                <i className="fas fa-robot text-yellow-500 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2">Auto Liquidity</h3>
              <p className="text-gray-400 text-sm">
                Automated market making ensures tight spreads and deep liquidity across all pairs.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Supported Networks */}
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-8">Supported Networks</h2>
          <div className="flex justify-center items-center space-x-12">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                <i className="fab fa-bitcoin text-white"></i>
              </div>
              <span className="text-lg font-medium">Bitcoin</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <i className="fab fa-ethereum text-white"></i>
              </div>
              <span className="text-lg font-medium">Ethereum</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                B
              </div>
              <span className="text-lg font-medium">Base</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
