import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Portfolio() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: wallets, isLoading: walletsLoading } = useQuery({
    queryKey: ["/api/wallets"],
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-crypto-secondary rounded w-48 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-crypto-secondary rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Calculate portfolio stats
  const totalBalance = wallets?.reduce((sum, wallet) => {
    const balance = parseFloat(wallet.balance || "0");
    const usdValue = balance * (wallet.cryptocurrency.symbol === "BTC" ? 43122.45 : 
                               wallet.cryptocurrency.symbol === "ETH" ? 1905.67 :
                               wallet.cryptocurrency.symbol === "BASE" ? 17.25 : 1);
    return sum + usdValue;
  }, 0) || 0;

  const previousBalance = totalBalance * 0.876; // Simulate 24h change
  const dayChange = totalBalance - previousBalance;
  const dayChangePercent = (dayChange / previousBalance) * 100;

  const bestPerformer = wallets?.reduce((best, wallet) => {
    const randomChange = Math.random() * 30 - 10; // Random change for demo
    return !best || randomChange > best.change ? 
      { ...wallet, change: randomChange } : best;
  }, null as any);

  return (
    <div className="flex-1 p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Portfolio Overview</h2>
        <p className="text-crypto-gray">Track your cryptocurrency investments and performance</p>
      </div>
      
      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">Total Value</h3>
            <p className="text-3xl font-bold">${totalBalance.toFixed(2)}</p>
            <div className="flex items-center mt-2">
              <span className={`${dayChange >= 0 ? "text-crypto-green" : "text-crypto-red"}`}>
                {dayChange >= 0 ? "+" : ""}${dayChange.toFixed(2)}
              </span>
              <span className="text-crypto-gray ml-2">
                ({dayChange >= 0 ? "+" : ""}{dayChangePercent.toFixed(1)}%)
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">24h Change</h3>
            <p className={`text-3xl font-bold ${dayChange >= 0 ? "text-crypto-green" : "text-crypto-red"}`}>
              {dayChange >= 0 ? "+" : ""}{dayChangePercent.toFixed(2)}%
            </p>
            <div className="flex items-center mt-2">
              <span className={`${dayChange >= 0 ? "text-crypto-green" : "text-crypto-red"}`}>
                {dayChange >= 0 ? "+" : ""}${dayChange.toFixed(2)}
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">Best Performer</h3>
            <p className="text-xl font-bold">
              {bestPerformer ? `${bestPerformer.cryptocurrency.name} (${bestPerformer.cryptocurrency.symbol})` : "N/A"}
            </p>
            <div className="flex items-center mt-2">
              <span className="text-crypto-green">
                +{bestPerformer ? bestPerformer.change.toFixed(1) : 0}%
              </span>
              <span className="text-crypto-gray ml-2">24h</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Asset Allocation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Asset Allocation</h3>
            <div className="space-y-4">
              {walletsLoading ? (
                [...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Skeleton className="w-10 h-10 rounded-full" />
                      <div>
                        <Skeleton className="h-4 w-16 mb-1" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                    </div>
                    <div className="text-right">
                      <Skeleton className="h-4 w-20 mb-1" />
                      <Skeleton className="h-3 w-12" />
                    </div>
                  </div>
                ))
              ) : wallets && wallets.length > 0 ? (
                wallets.map((wallet) => {
                  const balance = parseFloat(wallet.balance || "0");
                  const symbol = wallet.cryptocurrency.symbol;
                  const usdValue = balance * (symbol === "BTC" ? 43122.45 : 
                                             symbol === "ETH" ? 1905.67 :
                                             symbol === "BASE" ? 17.25 : 1);
                  const percentage = totalBalance > 0 ? (usdValue / totalBalance * 100).toFixed(1) : "0.0";
                  const change = Math.random() > 0.5 ? "+" : "-";
                  const changePercent = (Math.random() * 10).toFixed(1);
                  
                  const iconColor = symbol === "BTC" ? "bg-orange-500" :
                                   symbol === "ETH" ? "bg-blue-500" :
                                   symbol === "BASE" ? "bg-blue-600" : "bg-green-500";
                  
                  const icon = symbol === "BTC" ? "₿" :
                              symbol === "ETH" ? "Ξ" :
                              symbol === "BASE" ? "B" : "T";

                  return (
                    <div key={wallet.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${iconColor} rounded-full flex items-center justify-center font-bold text-white`}>
                          {icon}
                        </div>
                        <div>
                          <p className="font-medium">{wallet.cryptocurrency.name}</p>
                          <p className="text-sm text-crypto-gray">{percentage}% of portfolio</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${usdValue.toFixed(2)}</p>
                        <p className={`text-sm ${change === "+" ? "text-crypto-green" : "text-crypto-red"}`}>
                          {change}{changePercent}%
                        </p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8">
                  <p className="text-crypto-gray">No assets found. Start by depositing cryptocurrency.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Performance Chart Placeholder */}
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Portfolio Performance</h3>
            <div className="h-64 flex items-center justify-center">
              <div className="text-center">
                <i className="fas fa-chart-area text-4xl text-crypto-gray mb-4"></i>
                <p className="text-crypto-gray">Performance Chart</p>
                <p className="text-sm text-crypto-gray mt-2">Chart visualization would be implemented here</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
