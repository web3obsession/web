import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SwapData {
  fromSymbol: string;
  toSymbol: string;
  fromAmount: string;
  toAmount: string;
  exchangeRate: string;
  fee: string;
  feePercentage: string;
}

interface SwapSession {
  sessionId: string;
  depositAddress: string;
  expiresAt: string;
  fromAmount: string;
  toAmount: string;
  withdrawalAddress: string;
}

export default function QuickSwap() {
  const { toast } = useToast();
  const [fromCrypto, setFromCrypto] = useState("BTC");
  const [toCrypto, setToCrypto] = useState("ETH");
  const [fromAmount, setFromAmount] = useState("");
  const [withdrawalAddress, setWithdrawalAddress] = useState("");
  const [swapData, setSwapData] = useState<SwapData | null>(null);
  const [swapSession, setSwapSession] = useState<SwapSession | null>(null);
  const [step, setStep] = useState<"input" | "review" | "deposit">("input");

  const { data: cryptocurrencies } = useQuery({
    queryKey: ["/api/cryptocurrencies"],
  });

  // Calculate swap rate
  const calculateMutation = useMutation({
    mutationFn: async (data: { fromSymbol: string; toSymbol: string; amount: string }) => {
      const response = await apiRequest("POST", "/api/swap/calculate", data);
      return response.json();
    },
    onSuccess: (data) => {
      setSwapData(data);
    },
    onError: (error) => {
      toast({
        title: "Calculation Error",
        description: "Failed to calculate swap rate. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create swap session
  const createSwapMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/swap/create", data);
      return response.json();
    },
    onSuccess: (data) => {
      setSwapSession(data);
      setStep("deposit");
    },
    onError: (error) => {
      toast({
        title: "Swap Error",
        description: "Failed to create swap session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAmountChange = (value: string) => {
    setFromAmount(value);
    if (value && parseFloat(value) > 0) {
      calculateMutation.mutate({
        fromSymbol: fromCrypto,
        toSymbol: toCrypto,
        amount: value
      });
    } else {
      setSwapData(null);
    }
  };

  const handleSwapCurrencies = () => {
    const temp = fromCrypto;
    setFromCrypto(toCrypto);
    setToCrypto(temp);
    setFromAmount("");
    setSwapData(null);
  };

  const handleContinueSwap = () => {
    if (!swapData || !withdrawalAddress || !fromAmount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const fromCryptoData = cryptocurrencies?.find(c => c.symbol === fromCrypto);
    const toCryptoData = cryptocurrencies?.find(c => c.symbol === toCrypto);

    if (!fromCryptoData || !toCryptoData) {
      toast({
        title: "Invalid Cryptocurrency",
        description: "Selected cryptocurrencies are not supported.",
        variant: "destructive",
      });
      return;
    }

    createSwapMutation.mutate({
      fromCryptoId: fromCryptoData.id,
      toCryptoId: toCryptoData.id,
      fromAmount: swapData.fromAmount,
      toAmount: swapData.toAmount,
      exchangeRate: swapData.exchangeRate,
      fee: swapData.fee,
      withdrawalAddress,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Address copied to clipboard",
    });
  };

  const getCryptoIcon = (symbol: string) => {
    switch (symbol) {
      case "BTC":
        return <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold text-white">₿</div>;
      case "ETH":
        return <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold text-white">Ξ</div>;
      case "BASE":
        return <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-xs font-bold text-white">B</div>;
      default:
        return <div className="w-6 h-6 bg-gray-500 rounded-full flex items-center justify-center text-xs font-bold text-white">{symbol[0]}</div>;
    }
  };

  if (step === "deposit" && swapSession) {
    return (
      <div className="flex-1 p-6">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Send Your {fromCrypto}</h2>
            <p className="text-crypto-gray">Complete your swap by sending the exact amount below</p>
          </div>
          
          <Card className="bg-crypto-secondary border-crypto-border">
            <CardContent className="p-6 space-y-4">
              <div>
                <Label className="text-sm text-crypto-gray">Send exactly this amount:</Label>
                <div className="bg-crypto-dark p-3 rounded border flex items-center justify-between">
                  <span className="font-mono">{swapSession.fromAmount} {fromCrypto}</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => copyToClipboard(swapSession.fromAmount)}
                    className="text-crypto-accent text-sm"
                  >
                    Copy
                  </Button>
                </div>
              </div>
              
              <div>
                <Label className="text-sm text-crypto-gray">To this address:</Label>
                <div className="bg-crypto-dark p-3 rounded border flex items-center justify-between">
                  <span className="font-mono text-sm break-all">{swapSession.depositAddress}</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => copyToClipboard(swapSession.depositAddress)}
                    className="text-crypto-accent text-sm ml-2"
                  >
                    Copy
                  </Button>
                </div>
              </div>
              
              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4">
                <p className="text-yellow-200 text-sm">
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  Send the exact amount to avoid delays. Your {toCrypto} will be sent automatically once confirmed.
                </p>
              </div>

              <div className="bg-crypto-dark p-4 rounded-lg">
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-crypto-gray">You will receive:</span>
                    <span>{swapSession.toAmount} {toCrypto}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-crypto-gray">To address:</span>
                    <span className="font-mono text-xs break-all">{swapSession.withdrawalAddress}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-crypto-gray">Expires:</span>
                    <span>{new Date(swapSession.expiresAt).toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>

              <Button 
                onClick={() => {
                  setStep("input");
                  setSwapSession(null);
                }} 
                variant="outline" 
                className="w-full"
              >
                Start New Swap
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Quick Swap</h2>
          <p className="text-crypto-gray">No account required - instant crypto swapping</p>
        </div>
        
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            {/* From Section */}
            <div className="mb-4">
              <Label className="text-sm text-crypto-gray mb-2">From</Label>
              <div className="bg-crypto-dark border border-crypto-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <Select value={fromCrypto} onValueChange={setFromCrypto}>
                    <SelectTrigger className="w-32 bg-transparent border-none p-0 h-auto">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cryptocurrencies?.map((crypto) => (
                        <SelectItem key={crypto.id} value={crypto.symbol}>
                          <div className="flex items-center space-x-2">
                            {getCryptoIcon(crypto.symbol)}
                            <span>{crypto.symbol}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={fromAmount}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    className="text-right text-xl font-bold w-32 bg-transparent border-none p-0"
                  />
                </div>
                <div className="text-right text-sm text-crypto-gray">
                  ≈ ${swapData ? (parseFloat(swapData.fromAmount) * (fromCrypto === "BTC" ? 43122.45 : fromCrypto === "ETH" ? 1905.67 : 17.25)).toFixed(2) : "0.00"}
                </div>
              </div>
            </div>
            
            {/* Swap Button */}
            <div className="flex justify-center my-4">
              <Button 
                onClick={handleSwapCurrencies}
                className="w-10 h-10 bg-crypto-accent hover:bg-blue-600 rounded-full"
                size="sm"
              >
                <i className="fas fa-exchange-alt"></i>
              </Button>
            </div>
            
            {/* To Section */}
            <div className="mb-6">
              <Label className="text-sm text-crypto-gray mb-2">To</Label>
              <div className="bg-crypto-dark border border-crypto-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <Select value={toCrypto} onValueChange={setToCrypto}>
                    <SelectTrigger className="w-32 bg-transparent border-none p-0 h-auto">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {cryptocurrencies?.map((crypto) => (
                        <SelectItem key={crypto.id} value={crypto.symbol}>
                          <div className="flex items-center space-x-2">
                            {getCryptoIcon(crypto.symbol)}
                            <span>{crypto.symbol}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="text-right text-xl font-bold">
                    {swapData?.toAmount || "0.0"}
                  </div>
                </div>
                <div className="text-right text-sm text-crypto-gray">
                  ≈ ${swapData ? (parseFloat(swapData.toAmount) * (toCrypto === "BTC" ? 43122.45 : toCrypto === "ETH" ? 1905.67 : 17.25)).toFixed(2) : "0.00"}
                </div>
              </div>
            </div>
            
            {/* Rate Info */}
            {swapData && (
              <div className="bg-crypto-dark rounded-lg p-4 mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-crypto-gray">Rate</span>
                  <span>1 {fromCrypto} = {swapData.exchangeRate} {toCrypto}</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-crypto-gray">Fee</span>
                  <span>{swapData.feePercentage}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-crypto-gray">Estimated Time</span>
                  <span>~2 minutes</span>
                </div>
              </div>
            )}
            
            {/* Wallet Address Input */}
            <div className="mb-6">
              <Label className="text-sm text-crypto-gray mb-2">Your {toCrypto} Wallet Address</Label>
              <Input
                placeholder={`Enter ${toCrypto} address...`}
                value={withdrawalAddress}
                onChange={(e) => setWithdrawalAddress(e.target.value)}
                className="bg-crypto-dark border-crypto-border"
              />
            </div>
            
            {/* Continue Button */}
            <Button 
              onClick={handleContinueSwap}
              disabled={!swapData || !withdrawalAddress || createSwapMutation.isPending}
              className="w-full bg-crypto-green hover:bg-green-600"
            >
              {createSwapMutation.isPending ? "Creating Swap..." : "Continue Swap"}
            </Button>
            
            <p className="text-xs text-crypto-gray text-center mt-4">
              By continuing, you agree to our terms. No account registration required.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
