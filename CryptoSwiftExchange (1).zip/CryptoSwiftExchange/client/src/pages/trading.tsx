import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import OrderBook from "@/components/trading/order-book";
import PriceChart from "@/components/trading/price-chart";
import TradingPanel from "@/components/trading/trading-panel";

export default function Trading() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const { lastMessage } = useWebSocket();
  const [selectedPair, setSelectedPair] = useState<number>(1); // Default to BTC/USDT

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: tradingPairs, isLoading: pairsLoading } = useQuery({
    queryKey: ["/api/trading-pairs"],
    enabled: isAuthenticated,
  });

  const { data: orderBook, isLoading: orderBookLoading, refetch: refetchOrderBook } = useQuery({
    queryKey: [`/api/order-book/${selectedPair}`],
    enabled: isAuthenticated && !!selectedPair,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: priceHistory, isLoading: priceHistoryLoading } = useQuery({
    queryKey: [`/api/price-history/${selectedPair}`],
    enabled: isAuthenticated && !!selectedPair,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: userOrders, isLoading: ordersLoading, refetch: refetchOrders } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      if (lastMessage.type === 'orderbook' && lastMessage.pairId === selectedPair) {
        refetchOrderBook();
      } else if (lastMessage.type === 'price_update') {
        // Update prices in real-time
        refetchOrderBook();
      }
    }
  }, [lastMessage, selectedPair, refetchOrderBook]);

  if (isLoading || pairsLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-crypto-accent mx-auto"></div>
          <p className="mt-2 text-crypto-gray">Loading trading interface...</p>
        </div>
      </div>
    );
  }

  const currentPair = tradingPairs?.find(pair => pair.id === selectedPair);

  return (
    <div className="flex-1 p-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
        
        {/* Order Book */}
        <div className="lg:col-span-3">
          <OrderBook 
            orderBook={orderBook}
            currentPair={currentPair}
            tradingPairs={tradingPairs}
            selectedPair={selectedPair}
            onPairChange={setSelectedPair}
            isLoading={orderBookLoading}
          />
        </div>

        {/* Price Chart */}
        <div className="lg:col-span-6">
          <PriceChart 
            currentPair={currentPair}
            priceHistory={priceHistory}
            isLoading={priceHistoryLoading}
          />
        </div>

        {/* Trading Panel */}
        <div className="lg:col-span-3">
          <TradingPanel 
            currentPair={currentPair}
            userOrders={userOrders}
            onOrderPlaced={() => {
              refetchOrderBook();
              refetchOrders();
            }}
            isLoading={ordersLoading}
          />
        </div>
      </div>
    </div>
  );
}
