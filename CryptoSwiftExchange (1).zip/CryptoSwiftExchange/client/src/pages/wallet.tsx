import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import WalletCard from "@/components/wallet/wallet-card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Wallet() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedCrypto, setSelectedCrypto] = useState("BTC");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: wallets, isLoading: walletsLoading } = useQuery({
    queryKey: ["/api/wallets"],
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  const { data: cryptocurrencies } = useQuery({
    queryKey: ["/api/cryptocurrencies"],
    enabled: isAuthenticated,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  // Create wallet mutation
  const createWalletMutation = useMutation({
    mutationFn: async (cryptoSymbol: string) => {
      const response = await apiRequest("POST", "/api/wallets", { cryptoSymbol });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallets"] });
      toast({
        title: "Wallet Created",
        description: "Your new wallet has been created successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create wallet. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Mock deposit mutation
  const depositMutation = useMutation({
    mutationFn: async (data: { cryptoSymbol: string; amount: string }) => {
      const response = await apiRequest("POST", "/api/deposit", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Deposit Successful",
        description: "Your deposit has been processed successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Deposit Error",
        description: "Failed to process deposit. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Mock withdrawal mutation
  const withdrawMutation = useMutation({
    mutationFn: async (data: { cryptoSymbol: string; amount: string; address: string }) => {
      const response = await apiRequest("POST", "/api/withdraw", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Withdrawal Submitted",
        description: "Your withdrawal request has been submitted successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Withdrawal Error",
        description: "Failed to process withdrawal. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateWallet = (cryptoSymbol: string) => {
    createWalletMutation.mutate(cryptoSymbol);
  };

  const handleMockDeposit = () => {
    // For demo purposes - simulate deposit of 0.01 BTC
    depositMutation.mutate({
      cryptoSymbol: selectedCrypto,
      amount: selectedCrypto === "BTC" ? "0.01" : selectedCrypto === "ETH" ? "0.5" : "100"
    });
  };

  const handleWithdraw = () => {
    if (!withdrawAddress || !withdrawAmount) {
      toast({
        title: "Missing Information",
        description: "Please enter withdrawal address and amount.",
        variant: "destructive",
      });
      return;
    }

    withdrawMutation.mutate({
      cryptoSymbol: selectedCrypto,
      amount: withdrawAmount,
      address: withdrawAddress
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Address copied to clipboard",
    });
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-crypto-secondary rounded w-48 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-48 bg-crypto-secondary rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const supportedCryptos = cryptocurrencies || [];

  return (
    <div className="flex-1 p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Wallet Management</h2>
        <p className="text-crypto-gray">Manage your deposits and withdrawals across supported blockchains</p>
      </div>
      
      {/* Wallet Balances */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {walletsLoading ? (
          [...Array(3)].map((_, i) => (
            <Card key={i} className="bg-crypto-secondary border-crypto-border">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Skeleton className="w-12 h-12 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-20 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-8 w-32 mb-2" />
                <Skeleton className="h-4 w-24 mb-4" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 flex-1" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : wallets && wallets.length > 0 ? (
          wallets.map((wallet) => (
            <WalletCard 
              key={wallet.id}
              wallet={wallet}
              onCopyAddress={copyToClipboard}
            />
          ))
        ) : (
          <div className="col-span-full text-center py-8">
            <p className="text-crypto-gray mb-4">No wallets found. Create your first wallet below.</p>
          </div>
        )}
        
        {/* Create Wallet Cards for missing cryptocurrencies */}
        {supportedCryptos.map((crypto) => {
          const hasWallet = wallets?.some(w => w.cryptoId === crypto.id);
          if (hasWallet) return null;
          
          const iconColor = crypto.symbol === "BTC" ? "bg-orange-500" :
                           crypto.symbol === "ETH" ? "bg-blue-500" :
                           crypto.symbol === "BASE" ? "bg-blue-600" : "bg-green-500";
          
          const icon = crypto.symbol === "BTC" ? <i className="fab fa-bitcoin text-white"></i> :
                      crypto.symbol === "ETH" ? <i className="fab fa-ethereum text-white"></i> :
                      crypto.symbol === "BASE" ? <span className="text-white font-bold">B</span> :
                      <span className="text-white font-bold">{crypto.symbol[0]}</span>;

          return (
            <Card key={crypto.id} className="bg-crypto-secondary border-crypto-border border-dashed">
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 ${iconColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  {icon}
                </div>
                <h3 className="font-semibold mb-2">{crypto.name}</h3>
                <p className="text-sm text-crypto-gray mb-4">Create a {crypto.symbol} wallet</p>
                <Button 
                  onClick={() => handleCreateWallet(crypto.symbol)}
                  disabled={createWalletMutation.isPending}
                  className="w-full bg-crypto-accent hover:bg-blue-600"
                >
                  {createWalletMutation.isPending ? "Creating..." : "Create Wallet"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {/* Deposit/Withdraw Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Deposit */}
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Mock Deposit (Demo)</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm text-crypto-gray mb-2">Select Network</Label>
                <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                  <SelectTrigger className="bg-crypto-dark border-crypto-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedCryptos.map((crypto) => (
                      <SelectItem key={crypto.id} value={crypto.symbol}>
                        {crypto.name} ({crypto.symbol})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4">
                <p className="text-yellow-200 text-sm">
                  <i className="fas fa-info-circle mr-2"></i>
                  This is a demo deposit feature. In production, you would send real cryptocurrency to generated addresses.
                </p>
              </div>
              
              <Button 
                onClick={handleMockDeposit}
                disabled={depositMutation.isPending}
                className="w-full bg-crypto-accent hover:bg-blue-600"
              >
                {depositMutation.isPending ? "Processing..." : `Demo Deposit ${selectedCrypto}`}
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Withdraw */}
        <Card className="bg-crypto-secondary border-crypto-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Withdraw Funds</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm text-crypto-gray mb-2">Select Currency</Label>
                <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                  <SelectTrigger className="bg-crypto-dark border-crypto-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedCryptos.map((crypto) => (
                      <SelectItem key={crypto.id} value={crypto.symbol}>
                        {crypto.name} ({crypto.symbol})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-sm text-crypto-gray mb-2">Withdrawal Address</Label>
                <Input
                  placeholder={`Enter ${selectedCrypto} address`}
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  className="bg-crypto-dark border-crypto-border"
                />
              </div>
              
              <div>
                <Label className="text-sm text-crypto-gray mb-2">Amount</Label>
                <div className="relative">
                  <Input
                    type="number"
                    placeholder="0.00000000"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="bg-crypto-dark border-crypto-border pr-16"
                  />
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-crypto-accent text-sm h-auto p-1"
                  >
                    Max
                  </Button>
                </div>
                <div className="flex justify-between text-sm mt-1">
                  <span className="text-crypto-gray">Available: {
                    wallets?.find(w => w.cryptocurrency.symbol === selectedCrypto)?.balance || "0.00000000"
                  } {selectedCrypto}</span>
                  <span className="text-crypto-gray">Fee: 0.0005 {selectedCrypto}</span>
                </div>
              </div>
              
              <Button 
                onClick={handleWithdraw}
                className="w-full bg-crypto-red hover:bg-red-600"
                disabled={!withdrawAddress || !withdrawAmount || withdrawMutation.isPending}
              >
                {withdrawMutation.isPending ? "Processing..." : `Withdraw ${selectedCrypto}`}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Transaction History */}
      <Card className="bg-crypto-secondary border-crypto-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Wallet Activity</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-crypto-gray text-sm">
                  <th className="text-left py-2">Type</th>
                  <th className="text-left py-2">Asset</th>
                  <th className="text-left py-2">Amount</th>
                  <th className="text-left py-2">Status</th>
                  <th className="text-left py-2">Transaction ID</th>
                  <th className="text-left py-2">Time</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {transactionsLoading ? (
                  [...Array(3)].map((_, i) => (
                    <tr key={i} className="border-t border-crypto-border">
                      <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-12" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-20" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-24" /></td>
                      <td className="py-3"><Skeleton className="h-4 w-20" /></td>
                    </tr>
                  ))
                ) : transactions && transactions.length > 0 ? (
                  transactions.filter(tx => [1, 2].includes(tx.typeId)).map((tx) => {
                    const isDeposit = tx.typeId === 1;
                    const isWithdraw = tx.typeId === 2;
                    
                    return (
                      <tr key={tx.id} className="border-t border-crypto-border">
                        <td className="py-3">
                          <span className={`px-2 py-1 rounded text-xs ${
                            isDeposit ? "bg-crypto-green/20 text-crypto-green" : 
                            isWithdraw ? "bg-crypto-red/20 text-crypto-red" : 
                            "bg-crypto-accent/20 text-crypto-accent"
                          }`}>
                            {isDeposit ? "Deposit" : isWithdraw ? "Withdraw" : "Transaction"}
                          </span>
                        </td>
                        <td className="py-3">{tx.cryptocurrency.symbol}</td>
                        <td className="py-3">
                          {isDeposit ? "+" : "-"}{parseFloat(tx.amount).toFixed(8)}
                        </td>
                        <td className="py-3">
                          <span className={`${
                            tx.status === "completed" ? "text-crypto-green" : 
                            tx.status === "pending" ? "text-yellow-500" : "text-crypto-red"
                          }`}>
                            {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-3">
                          <code className="text-crypto-gray text-xs">
                            {tx.externalTxId?.slice(0, 8)}...{tx.externalTxId?.slice(-8)}
                          </code>
                        </td>
                        <td className="py-3 text-crypto-gray">
                          {new Date(tx.createdAt || '').toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-crypto-gray">
                      No wallet transactions found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
