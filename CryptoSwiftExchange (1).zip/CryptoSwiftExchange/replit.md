# CryptoVault Trading Platform

## Overview

CryptoVault is a professional cryptocurrency trading platform built with a full-stack TypeScript architecture. It provides advanced trading features, instant cryptocurrency swaps, secure wallet management, and real-time market data across Bitcoin, Ethereum, and Base networks. The platform supports both authenticated users with full trading capabilities and anonymous users with limited quick-swap functionality.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Framework**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom crypto-themed design system
- **Real-time Updates**: WebSocket integration for live price feeds and order book updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth with OpenID Connect integration
- **Session Management**: Express sessions with PostgreSQL storage
- **Real-time Communication**: WebSocket server for broadcasting price updates

### Database Design
The system uses PostgreSQL with the following key entities:
- **Users**: Replit Auth integration with profile management
- **Cryptocurrencies**: Supported coins (BTC, ETH, BASE, USDT) with network configurations
- **Wallets**: User balances for each cryptocurrency
- **Trading Pairs**: Available trading combinations with spread configurations
- **Orders**: Buy/sell orders with market/limit types
- **Transactions**: All financial movements with status tracking
- **Swap Sessions**: Anonymous swap sessions for quick trading
- **Price History**: Historical price data for charting

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with 7-day expiration
- **Authorization**: Route-level middleware protecting authenticated endpoints
- **User Management**: Automatic user creation and profile synchronization

### Trading Engine
- **Order Types**: Market and limit orders for buy/sell operations
- **Order Book**: Real-time bid/ask management with automatic matching
- **Price Discovery**: Dynamic pricing with configurable spreads
- **Liquidity Management**: Automated market making with volume controls

### Wallet System
- **Multi-currency Support**: BTC, ETH, BASE, and USDT wallets
- **Balance Management**: Real-time balance updates with transaction logging
- **Deposit/Withdrawal**: Simulated external blockchain interactions
- **Security**: Balance validation and transaction integrity checks

### Real-time Services
- **Price Service**: Simulated market data with realistic price movements
- **Liquidity Service**: Automated order placement for market depth
- **WebSocket Broadcasting**: Live updates to all connected clients
- **Market Data**: Order book updates, price changes, and volume metrics

## Data Flow

1. **User Authentication**: Replit Auth handles login/logout with session management
2. **Market Data**: Background services generate realistic price movements and broadcast updates
3. **Trading Operations**: Users place orders through the trading panel, which updates the order book
4. **Real-time Updates**: WebSocket connections push live data to all connected clients
5. **Wallet Operations**: Balance changes trigger transaction records and wallet updates
6. **Quick Swap**: Anonymous users can perform instant swaps with temporary session tracking

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon database
- **drizzle-orm**: Type-safe database operations with PostgreSQL dialect
- **@tanstack/react-query**: Server state management and caching
- **express**: Web server framework with middleware support
- **passport**: Authentication middleware for Replit Auth integration

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives for form controls and overlays
- **tailwindcss**: Utility-first CSS framework with custom design tokens
- **wouter**: Lightweight client-side routing
- **ws**: WebSocket implementation for real-time communication

### Development Dependencies
- **vite**: Fast build tool with TypeScript support
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling for server code

## Deployment Strategy

### Development Environment
- **Frontend**: Vite development server with hot module replacement
- **Backend**: tsx for TypeScript execution with auto-reload
- **Database**: Neon PostgreSQL with environment-based connection strings
- **Real-time**: WebSocket server integrated with Express HTTP server

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations ensure schema consistency
- **Deployment**: Single Node.js process serving both API and static files

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption key (required)
- **REPL_ID**: Replit environment identifier for auth
- **NODE_ENV**: Environment mode (development/production)

## Changelog
- July 05, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.