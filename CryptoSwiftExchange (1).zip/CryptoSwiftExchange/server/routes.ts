import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { liquidityService } from "./services/liquidityService";
import { priceService } from "./services/priceService";
import { insertOrderSchema, insertSwapSessionSchema } from "@shared/schema";
import { z } from "zod";
import { nanoid } from "nanoid";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize default data
  await storage.initializeDefaultData();

  // Auth middleware
  await setupAuth(app);

  // WebSocket for real-time updates
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Broadcast price updates to all connected clients
  const broadcastPriceUpdate = (data: any) => {
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // WebSocket connection handling
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // Start background services
  liquidityService.start(storage, broadcastPriceUpdate);
  priceService.start(storage, broadcastPriceUpdate);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Public routes (no auth required)
  
  // Get supported cryptocurrencies
  app.get('/api/cryptocurrencies', async (req, res) => {
    try {
      const cryptos = await storage.getCryptocurrencies();
      res.json(cryptos);
    } catch (error) {
      console.error("Error fetching cryptocurrencies:", error);
      res.status(500).json({ message: "Failed to fetch cryptocurrencies" });
    }
  });

  // Get trading pairs
  app.get('/api/trading-pairs', async (req, res) => {
    try {
      const pairs = await storage.getTradingPairs();
      res.json(pairs);
    } catch (error) {
      console.error("Error fetching trading pairs:", error);
      res.status(500).json({ message: "Failed to fetch trading pairs" });
    }
  });

  // Get order book for a trading pair
  app.get('/api/order-book/:pairId', async (req, res) => {
    try {
      const pairId = parseInt(req.params.pairId);
      const orderBook = await storage.getOrderBook(pairId);
      res.json(orderBook);
    } catch (error) {
      console.error("Error fetching order book:", error);
      res.status(500).json({ message: "Failed to fetch order book" });
    }
  });

  // Get price history for charts
  app.get('/api/price-history/:pairId', async (req, res) => {
    try {
      const pairId = parseInt(req.params.pairId);
      const hours = parseInt(req.query.hours as string) || 24;
      const history = await storage.getPriceHistory(pairId, hours);
      res.json(history);
    } catch (error) {
      console.error("Error fetching price history:", error);
      res.status(500).json({ message: "Failed to fetch price history" });
    }
  });

  // Quick swap routes (no auth required)
  
  // Calculate swap rate
  app.post('/api/swap/calculate', async (req, res) => {
    try {
      const { fromSymbol, toSymbol, amount } = req.body;
      
      const fromCrypto = await storage.getCryptocurrencyBySymbol(fromSymbol);
      const toCrypto = await storage.getCryptocurrencyBySymbol(toSymbol);
      
      if (!fromCrypto || !toCrypto) {
        return res.status(400).json({ message: "Invalid cryptocurrency symbols" });
      }

      // Get current exchange rate (simplified - in production would use real market data)
      const exchangeRate = priceService.getExchangeRate(fromSymbol, toSymbol);
      const fee = parseFloat(amount) * 0.0025; // 0.25% fee
      const toAmount = (parseFloat(amount) * exchangeRate) - fee;

      res.json({
        fromAmount: amount,
        toAmount: toAmount.toFixed(8),
        exchangeRate: exchangeRate.toFixed(8),
        fee: fee.toFixed(8),
        feePercentage: "0.25"
      });
    } catch (error) {
      console.error("Error calculating swap:", error);
      res.status(500).json({ message: "Failed to calculate swap" });
    }
  });

  // Create swap session
  app.post('/api/swap/create', async (req, res) => {
    try {
      const validation = insertSwapSessionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid swap data", errors: validation.error.errors });
      }

      const sessionId = nanoid();
      const depositAddress = generateMockAddress(validation.data.fromCryptoId);
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes

      const session = await storage.createSwapSession({
        ...validation.data,
        sessionId,
        depositAddress,
        expiresAt
      });

      res.json({
        sessionId: session.sessionId,
        depositAddress: session.depositAddress,
        expiresAt: session.expiresAt,
        fromAmount: session.fromAmount,
        toAmount: session.toAmount,
        withdrawalAddress: session.withdrawalAddress
      });
    } catch (error) {
      console.error("Error creating swap session:", error);
      res.status(500).json({ message: "Failed to create swap session" });
    }
  });

  // Get swap session status
  app.get('/api/swap/:sessionId', async (req, res) => {
    try {
      const session = await storage.getSwapSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ message: "Swap session not found" });
      }
      res.json(session);
    } catch (error) {
      console.error("Error fetching swap session:", error);
      res.status(500).json({ message: "Failed to fetch swap session" });
    }
  });

  // Protected routes (auth required)
  
  // Get user wallets
  app.get('/api/wallets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const wallets = await storage.getUserWallets(userId);
      res.json(wallets);
    } catch (error) {
      console.error("Error fetching wallets:", error);
      res.status(500).json({ message: "Failed to fetch wallets" });
    }
  });

  // Create wallet for user
  app.post('/api/wallets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { cryptoSymbol } = req.body;
      
      const crypto = await storage.getCryptocurrencyBySymbol(cryptoSymbol);
      if (!crypto) {
        return res.status(400).json({ message: "Invalid cryptocurrency" });
      }

      // Check if wallet already exists
      const existingWallet = await storage.getWallet(userId, crypto.id);
      if (existingWallet) {
        return res.status(400).json({ message: "Wallet already exists for this cryptocurrency" });
      }

      // Generate mock address
      const address = generateMockAddress(crypto.id);
      
      const wallet = await storage.createWallet({
        userId,
        cryptoId: crypto.id,
        address,
        balance: "0"
      });

      res.json(wallet);
    } catch (error) {
      console.error("Error creating wallet:", error);
      res.status(500).json({ message: "Failed to create wallet" });
    }
  });

  // Get user transactions
  app.get('/api/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 50;
      const transactions = await storage.getUserTransactions(userId, limit);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Create order
  app.post('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validation = insertOrderSchema.safeParse({
        ...req.body,
        userId
      });
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid order data", errors: validation.error.errors });
      }

      const order = await storage.createOrder(validation.data);
      
      // Broadcast order book update
      const orderBook = await storage.getOrderBook(validation.data.pairId);
      broadcastPriceUpdate({
        type: 'orderbook',
        pairId: validation.data.pairId,
        data: orderBook
      });

      res.json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Get user orders
  app.get('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const orders = await storage.getUserOrders(userId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Cancel order
  app.delete('/api/orders/:orderId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const orderId = parseInt(req.params.orderId);
      
      const success = await storage.cancelOrder(orderId, userId);
      if (!success) {
        return res.status(404).json({ message: "Order not found or already cancelled" });
      }

      res.json({ message: "Order cancelled successfully" });
    } catch (error) {
      console.error("Error cancelling order:", error);
      res.status(500).json({ message: "Failed to cancel order" });
    }
  });

  // Mock deposit (for demo purposes)
  app.post('/api/deposit', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { cryptoSymbol, amount } = req.body;
      
      const crypto = await storage.getCryptocurrencyBySymbol(cryptoSymbol);
      if (!crypto) {
        return res.status(400).json({ message: "Invalid cryptocurrency" });
      }

      // Simulate deposit transaction
      const transaction = await storage.createTransaction({
        userId,
        typeId: 1, // deposit
        cryptoId: crypto.id,
        amount,
        fee: "0",
        status: "completed",
        externalTxId: nanoid(),
        toAddress: generateMockAddress(crypto.id)
      });

      res.json(transaction);
    } catch (error) {
      console.error("Error processing deposit:", error);
      res.status(500).json({ message: "Failed to process deposit" });
    }
  });

  // Mock withdrawal (for demo purposes)
  app.post('/api/withdraw', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { cryptoSymbol, amount, address } = req.body;
      
      const crypto = await storage.getCryptocurrencyBySymbol(cryptoSymbol);
      if (!crypto) {
        return res.status(400).json({ message: "Invalid cryptocurrency" });
      }

      // Simulate withdrawal transaction
      const transaction = await storage.createTransaction({
        userId,
        typeId: 2, // withdrawal
        cryptoId: crypto.id,
        amount,
        fee: (parseFloat(amount) * 0.001).toString(), // 0.1% withdrawal fee
        status: "pending",
        externalTxId: nanoid(),
        fromAddress: generateMockAddress(crypto.id),
        toAddress: address
      });

      res.json(transaction);
    } catch (error) {
      console.error("Error processing withdrawal:", error);
      res.status(500).json({ message: "Failed to process withdrawal" });
    }
  });

  function generateMockAddress(cryptoId: number): string {
    const addresses = {
      1: `bc1${nanoid(39)}`, // Bitcoin
      2: `0x${nanoid(40)}`, // Ethereum
      3: `0x${nanoid(40)}`, // Base
      4: `0x${nanoid(40)}`, // USDT
    };
    return addresses[cryptoId as keyof typeof addresses] || `addr_${nanoid(20)}`;
  }

  return httpServer;
}
