import type { IStorage } from "../storage";

interface LiquidityConfig {
  maxSpreadPercent: number; // 8%
  maxVolumePercent: number; // 50%
  updateInterval: number; // 5 minutes
}

class LiquidityService {
  private isRunning = false;
  private config: LiquidityConfig = {
    maxSpreadPercent: 8,
    maxVolumePercent: 50,
    updateInterval: 5 * 60 * 1000, // 5 minutes
  };

  async start(storage: IStorage, broadcastUpdate: (data: any) => void) {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log("Liquidity service started");

    // Run initial liquidity check
    await this.manageLiquidity(storage, broadcastUpdate);

    // Set up periodic liquidity management
    setInterval(async () => {
      if (this.isRunning) {
        await this.manageLiquidity(storage, broadcastUpdate);
      }
    }, this.config.updateInterval);
  }

  stop() {
    this.isRunning = false;
    console.log("Liquidity service stopped");
  }

  private async manageLiquidity(storage: IStorage, broadcastUpdate: (data: any) => void) {
    try {
      const pairs = await storage.getTradingPairs();
      
      for (const pair of pairs) {
        await this.managePairLiquidity(storage, pair.id, broadcastUpdate);
      }
    } catch (error) {
      console.error("Error managing liquidity:", error);
    }
  }

  private async managePairLiquidity(storage: IStorage, pairId: number, broadcastUpdate: (data: any) => void) {
    try {
      const orderBook = await storage.getOrderBook(pairId);
      const currentPrice = await storage.getCurrentPrice(pairId);
      
      if (!currentPrice) return;

      const price = parseFloat(currentPrice);
      const spread = this.calculateSpread(orderBook.bids, orderBook.asks, price);
      
      if (spread > this.config.maxSpreadPercent) {
        // Remove existing liquidity orders
        await storage.deleteLiquidityOrders(pairId);
        
        // Calculate optimal order placement
        const liquidityOrders = this.calculateLiquidityOrders(
          price,
          orderBook.bids,
          orderBook.asks
        );
        
        // Place new liquidity orders
        for (const order of liquidityOrders) {
          await storage.createOrder({
            userId: null, // System orders
            pairId,
            type: order.type,
            orderType: "limit",
            amount: order.amount,
            price: order.price,
            isLiquidityOrder: true
          });
        }
        
        // Broadcast updated order book
        const updatedOrderBook = await storage.getOrderBook(pairId);
        broadcastUpdate({
          type: 'orderbook',
          pairId,
          data: updatedOrderBook
        });
        
        console.log(`Added liquidity for pair ${pairId}, spread was ${spread.toFixed(2)}%`);
      }
    } catch (error) {
      console.error(`Error managing liquidity for pair ${pairId}:`, error);
    }
  }

  private calculateSpread(bids: any[], asks: any[], currentPrice: number): number {
    if (bids.length === 0 || asks.length === 0) return 100; // Max spread if no orders
    
    const bestBid = Math.max(...bids.map(b => parseFloat(b.price)));
    const bestAsk = Math.min(...asks.map(a => parseFloat(a.price)));
    
    return ((bestAsk - bestBid) / currentPrice) * 100;
  }

  private calculateLiquidityOrders(
    currentPrice: number,
    existingBids: any[],
    existingAsks: any[]
  ): Array<{ type: string; price: string; amount: string }> {
    const orders = [];
    
    // Calculate spread levels
    const levels = [0.5, 1.0, 1.5, 2.0]; // Percentage levels from current price
    
    for (const level of levels) {
      const bidPrice = currentPrice * (1 - level / 100);
      const askPrice = currentPrice * (1 + level / 100);
      
      // Calculate order sizes based on existing orders
      const bidAmount = this.calculateOrderAmount(existingBids, bidPrice);
      const askAmount = this.calculateOrderAmount(existingAsks, askPrice);
      
      if (bidAmount > 0) {
        orders.push({
          type: "buy",
          price: bidPrice.toFixed(2),
          amount: bidAmount.toFixed(8)
        });
      }
      
      if (askAmount > 0) {
        orders.push({
          type: "sell",
          price: askPrice.toFixed(2),
          amount: askAmount.toFixed(8)
        });
      }
    }
    
    return orders;
  }

  private calculateOrderAmount(existingOrders: any[], targetPrice: number): number {
    // Find adjacent orders to calculate appropriate volume
    const adjacentOrders = existingOrders.filter(order => {
      const orderPrice = parseFloat(order.price);
      return Math.abs(orderPrice - targetPrice) < targetPrice * 0.02; // Within 2%
    });
    
    if (adjacentOrders.length === 0) {
      // Base amount for new levels
      return 0.1; // Default small amount
    }
    
    // Calculate max 50% of adjacent order volume
    const avgVolume = adjacentOrders.reduce((sum, order) => sum + parseFloat(order.amount), 0) / adjacentOrders.length;
    return Math.min(avgVolume * this.config.maxVolumePercent / 100, 1.0);
  }
}

export const liquidityService = new LiquidityService();
