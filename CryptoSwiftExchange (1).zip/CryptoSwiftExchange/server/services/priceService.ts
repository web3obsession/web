import type { IStorage } from "../storage";

interface PriceData {
  [symbol: string]: number;
}

class PriceService {
  private isRunning = false;
  private prices: PriceData = {
    "BTC": 43122.45,
    "ETH": 1905.67,
    "BASE": 17.2548,
    "USDT": 1.0
  };
  private updateInterval = 10000; // 10 seconds

  async start(storage: IStorage, broadcastUpdate: (data: any) => void) {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log("Price service started");

    // Set up periodic price updates
    setInterval(async () => {
      if (this.isRunning) {
        await this.updatePrices(storage, broadcastUpdate);
      }
    }, this.updateInterval);
  }

  stop() {
    this.isRunning = false;
    console.log("Price service stopped");
  }

  getExchangeRate(fromSymbol: string, toSymbol: string): number {
    if (fromSymbol === toSymbol) return 1;
    
    const fromPrice = this.prices[fromSymbol] || 1;
    const toPrice = this.prices[toSymbol] || 1;
    
    return fromPrice / toPrice;
  }

  getCurrentPrice(symbol: string): number {
    return this.prices[symbol] || 0;
  }

  private async updatePrices(storage: IStorage, broadcastUpdate: (data: any) => void) {
    try {
      // Simulate price movements (in production, would fetch from real API)
      for (const symbol of Object.keys(this.prices)) {
        const currentPrice = this.prices[symbol];
        const change = (Math.random() - 0.5) * 0.02; // ±1% change
        const newPrice = currentPrice * (1 + change);
        this.prices[symbol] = Math.max(newPrice, 0.01); // Prevent negative prices
      }

      // Update price history in database
      const pairs = await storage.getTradingPairs();
      
      for (const pair of pairs) {
        const basePrice = this.prices[pair.baseCrypto.symbol];
        const quotePrice = this.prices[pair.quoteCrypto.symbol];
        
        if (basePrice && quotePrice) {
          const pairPrice = basePrice / quotePrice;
          const volume = Math.random() * 100; // Random volume for demo
          
          await storage.addPriceHistory(pair.id, pairPrice.toFixed(2), volume.toFixed(2));
        }
      }

      // Broadcast price updates
      broadcastUpdate({
        type: 'price_update',
        data: this.prices
      });

    } catch (error) {
      console.error("Error updating prices:", error);
    }
  }
}

export const priceService = new PriceService();
