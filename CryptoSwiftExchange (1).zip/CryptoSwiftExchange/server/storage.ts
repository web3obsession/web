import {
  users,
  cryptocurrencies,
  wallets,
  transactions,
  tradingPairs,
  orders,
  swapSessions,
  priceHistory,
  transactionTypes,
  type User,
  type UpsertUser,
  type Cryptocurrency,
  type InsertCryptocurrency,
  type Wallet,
  type InsertWallet,
  type Transaction,
  type InsertTransaction,
  type TradingPair,
  type InsertTradingPair,
  type Order,
  type InsertOrder,
  type SwapSession,
  type InsertSwapSession,
  type PriceHistory,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Cryptocurrency operations
  getCryptocurrencies(): Promise<Cryptocurrency[]>;
  getCryptocurrencyBySymbol(symbol: string): Promise<Cryptocurrency | undefined>;
  
  // Wallet operations
  getUserWallets(userId: string): Promise<(Wallet & { cryptocurrency: Cryptocurrency })[]>;
  getWallet(userId: string, cryptoId: number): Promise<Wallet | undefined>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(walletId: number, balance: string): Promise<void>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: string, limit?: number): Promise<(Transaction & { cryptocurrency: Cryptocurrency })[]>;
  updateTransactionStatus(transactionId: number, status: string): Promise<void>;
  
  // Trading operations
  getTradingPairs(): Promise<(TradingPair & { baseCrypto: Cryptocurrency; quoteCrypto: Cryptocurrency })[]>;
  getTradingPair(id: number): Promise<(TradingPair & { baseCrypto: Cryptocurrency; quoteCrypto: Cryptocurrency }) | undefined>;
  getTradingPairBySymbol(symbol: string): Promise<(TradingPair & { baseCrypto: Cryptocurrency; quoteCrypto: Cryptocurrency }) | undefined>;
  
  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  getUserOrders(userId: string): Promise<(Order & { pair: TradingPair })[]>;
  getOrderBook(pairId: number): Promise<{ bids: Order[]; asks: Order[] }>;
  updateOrderStatus(orderId: number, status: string, filled?: string): Promise<void>;
  cancelOrder(orderId: number, userId: string): Promise<boolean>;
  
  // Liquidity operations
  getLiquidityOrders(pairId: number): Promise<Order[]>;
  deleteLiquidityOrders(pairId: number): Promise<void>;
  
  // Price operations
  getCurrentPrice(pairId: number): Promise<string | undefined>;
  addPriceHistory(pairId: number, price: string, volume: string): Promise<void>;
  getPriceHistory(pairId: number, hours: number): Promise<PriceHistory[]>;
  
  // Quick swap operations
  createSwapSession(session: InsertSwapSession): Promise<SwapSession>;
  getSwapSession(sessionId: string): Promise<SwapSession | undefined>;
  updateSwapSession(sessionId: string, data: Partial<SwapSession>): Promise<void>;
  
  // Initialization
  initializeDefaultData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getCryptocurrencies(): Promise<Cryptocurrency[]> {
    return await db.select().from(cryptocurrencies).where(eq(cryptocurrencies.isActive, true));
  }

  async getCryptocurrencyBySymbol(symbol: string): Promise<Cryptocurrency | undefined> {
    const [crypto] = await db.select().from(cryptocurrencies).where(eq(cryptocurrencies.symbol, symbol));
    return crypto;
  }

  async getUserWallets(userId: string): Promise<any[]> {
    return await db.query.wallets.findMany({
      where: eq(wallets.userId, userId),
      with: {
        cryptocurrency: true,
      },
    });
  }

  async getWallet(userId: string, cryptoId: number): Promise<Wallet | undefined> {
    const [wallet] = await db
      .select()
      .from(wallets)
      .where(and(eq(wallets.userId, userId), eq(wallets.cryptoId, cryptoId)));
    return wallet;
  }

  async createWallet(walletData: InsertWallet): Promise<Wallet> {
    const [wallet] = await db.insert(wallets).values(walletData).returning();
    return wallet;
  }

  async updateWalletBalance(walletId: number, balance: string): Promise<void> {
    await db
      .update(wallets)
      .set({ balance, updatedAt: new Date() })
      .where(eq(wallets.id, walletId));
  }

  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(transactionData).returning();
    return transaction;
  }

  async getUserTransactions(userId: string, limit = 50): Promise<any[]> {
    return await db.query.transactions.findMany({
      where: eq(transactions.userId, userId),
      with: {
        cryptocurrency: true,
      },
      orderBy: [desc(transactions.createdAt)],
      limit: limit,
    });
  }

  async updateTransactionStatus(transactionId: number, status: string): Promise<void> {
    await db
      .update(transactions)
      .set({ status, updatedAt: new Date() })
      .where(eq(transactions.id, transactionId));
  }

  async getTradingPairs(): Promise<any[]> {
    return await db.query.tradingPairs.findMany({
      where: eq(tradingPairs.isActive, true),
      with: {
        baseCrypto: true,
        quoteCrypto: true,
      },
    });
  }

  async getTradingPair(id: number): Promise<any> {
    return await db.query.tradingPairs.findFirst({
      where: eq(tradingPairs.id, id),
      with: {
        baseCrypto: true,
        quoteCrypto: true,
      },
    });
  }

  async getTradingPairBySymbol(symbol: string): Promise<any> {
    return await db.query.tradingPairs.findFirst({
      where: eq(tradingPairs.symbol, symbol),
      with: {
        baseCrypto: true,
        quoteCrypto: true,
      },
    });
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const [order] = await db.insert(orders).values(orderData).returning();
    return order;
  }

  async getUserOrders(userId: string): Promise<any[]> {
    return await db.query.orders.findMany({
      where: eq(orders.userId, userId),
      with: {
        pair: true,
      },
      orderBy: [desc(orders.createdAt)],
    });
  }

  async getOrderBook(pairId: number): Promise<{ bids: Order[]; asks: Order[] }> {
    const allOrders = await db
      .select()
      .from(orders)
      .where(and(eq(orders.pairId, pairId), eq(orders.status, "active")))
      .orderBy(orders.price);

    const bids = allOrders.filter(order => order.type === "buy").reverse();
    const asks = allOrders.filter(order => order.type === "sell");

    return { bids, asks };
  }

  async updateOrderStatus(orderId: number, status: string, filled?: string): Promise<void> {
    const updateData: any = { status, updatedAt: new Date() };
    if (filled !== undefined) {
      updateData.filled = filled;
    }
    
    await db
      .update(orders)
      .set(updateData)
      .where(eq(orders.id, orderId));
  }

  async cancelOrder(orderId: number, userId: string): Promise<boolean> {
    const result = await db
      .update(orders)
      .set({ status: "cancelled", updatedAt: new Date() })
      .where(and(eq(orders.id, orderId), eq(orders.userId, userId), eq(orders.status, "active")));
    
    return (result.rowCount ?? 0) > 0;
  }

  async getLiquidityOrders(pairId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(and(eq(orders.pairId, pairId), eq(orders.isLiquidityOrder, true), eq(orders.status, "active")));
  }

  async deleteLiquidityOrders(pairId: number): Promise<void> {
    await db
      .delete(orders)
      .where(and(eq(orders.pairId, pairId), eq(orders.isLiquidityOrder, true)));
  }

  async getCurrentPrice(pairId: number): Promise<string | undefined> {
    const [result] = await db
      .select({ price: priceHistory.price })
      .from(priceHistory)
      .where(eq(priceHistory.pairId, pairId))
      .orderBy(desc(priceHistory.timestamp))
      .limit(1);
    
    return result?.price;
  }

  async addPriceHistory(pairId: number, price: string, volume: string): Promise<void> {
    await db.insert(priceHistory).values({
      pairId,
      price,
      volume,
      timestamp: new Date(),
    });
  }

  async getPriceHistory(pairId: number, hours: number): Promise<PriceHistory[]> {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    return await db
      .select()
      .from(priceHistory)
      .where(and(eq(priceHistory.pairId, pairId), gte(priceHistory.timestamp, since)))
      .orderBy(priceHistory.timestamp);
  }

  async createSwapSession(sessionData: InsertSwapSession): Promise<SwapSession> {
    const [session] = await db.insert(swapSessions).values(sessionData).returning();
    return session;
  }

  async getSwapSession(sessionId: string): Promise<SwapSession | undefined> {
    const [session] = await db
      .select()
      .from(swapSessions)
      .where(eq(swapSessions.sessionId, sessionId));
    return session;
  }

  async updateSwapSession(sessionId: string, data: Partial<SwapSession>): Promise<void> {
    await db
      .update(swapSessions)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(swapSessions.sessionId, sessionId));
  }

  async initializeDefaultData(): Promise<void> {
    // Initialize transaction types
    const txTypes = [
      { name: "deposit" },
      { name: "withdraw" },
      { name: "trade" },
      { name: "swap" }
    ];

    for (const type of txTypes) {
      await db.insert(transactionTypes).values(type).onConflictDoNothing();
    }

    // Initialize cryptocurrencies
    const cryptos = [
      { symbol: "BTC", name: "Bitcoin", network: "Bitcoin", decimals: 8 },
      { symbol: "ETH", name: "Ethereum", network: "Ethereum", decimals: 18 },
      { symbol: "BASE", name: "Base", network: "Base", decimals: 18 },
      { symbol: "USDT", name: "Tether USD", network: "Ethereum", decimals: 6 }
    ];

    for (const crypto of cryptos) {
      await db.insert(cryptocurrencies).values(crypto).onConflictDoNothing();
    }

    // Initialize trading pairs
    const btc = await this.getCryptocurrencyBySymbol("BTC");
    const eth = await this.getCryptocurrencyBySymbol("ETH");
    const base = await this.getCryptocurrencyBySymbol("BASE");
    const usdt = await this.getCryptocurrencyBySymbol("USDT");

    if (btc && eth && base && usdt) {
      const pairs = [
        {
          baseCryptoId: btc.id,
          quoteCryptoId: usdt.id,
          symbol: "BTC/USDT",
          minOrderSize: "0.0001",
          maxOrderSize: "1000",
          priceDecimals: 2,
          amountDecimals: 8
        },
        {
          baseCryptoId: eth.id,
          quoteCryptoId: usdt.id,
          symbol: "ETH/USDT",
          minOrderSize: "0.001",
          maxOrderSize: "10000",
          priceDecimals: 2,
          amountDecimals: 8
        },
        {
          baseCryptoId: base.id,
          quoteCryptoId: usdt.id,
          symbol: "BASE/USDT",
          minOrderSize: "1",
          maxOrderSize: "1000000",
          priceDecimals: 4,
          amountDecimals: 2
        }
      ];

      for (const pair of pairs) {
        await db.insert(tradingPairs).values(pair).onConflictDoNothing();
      }

      // Initialize price history with some sample data
      const now = new Date();
      const btcPair = await this.getTradingPairBySymbol("BTC/USDT");
      const ethPair = await this.getTradingPairBySymbol("ETH/USDT");
      const basePair = await this.getTradingPairBySymbol("BASE/USDT");

      if (btcPair) {
        await db.insert(priceHistory).values({
          pairId: btcPair.id,
          price: "43122.45",
          volume: "1500.5",
          timestamp: now
        }).onConflictDoNothing();
      }

      if (ethPair) {
        await db.insert(priceHistory).values({
          pairId: ethPair.id,
          price: "1905.67",
          volume: "2300.2",
          timestamp: now
        }).onConflictDoNothing();
      }

      if (basePair) {
        await db.insert(priceHistory).values({
          pairId: basePair.id,
          price: "17.2548",
          volume: "45000.8",
          timestamp: now
        }).onConflictDoNothing();
      }
    }
  }
}

export const storage = new DatabaseStorage();
