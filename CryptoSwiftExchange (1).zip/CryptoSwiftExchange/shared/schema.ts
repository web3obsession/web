import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  decimal,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Supported cryptocurrencies
export const cryptocurrencies = pgTable("cryptocurrencies", {
  id: serial("id").primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  network: varchar("network", { length: 50 }).notNull(),
  decimals: integer("decimals").notNull().default(8),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User wallets for each cryptocurrency
export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  cryptoId: integer("crypto_id").notNull().references(() => cryptocurrencies.id),
  address: varchar("address", { length: 255 }).notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Transaction types
export const transactionTypes = pgTable("transaction_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(), // deposit, withdraw, trade, swap
});

// All transactions (deposits, withdrawals, trades)
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  typeId: integer("type_id").notNull().references(() => transactionTypes.id),
  cryptoId: integer("crypto_id").notNull().references(() => cryptocurrencies.id),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  fee: decimal("fee", { precision: 20, scale: 8 }).notNull().default("0"),
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, completed, failed, cancelled
  externalTxId: varchar("external_tx_id", { length: 255 }),
  fromAddress: varchar("from_address", { length: 255 }),
  toAddress: varchar("to_address", { length: 255 }),
  metadata: jsonb("metadata"), // Additional data like swap details
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Trading pairs
export const tradingPairs = pgTable("trading_pairs", {
  id: serial("id").primaryKey(),
  baseCryptoId: integer("base_crypto_id").notNull().references(() => cryptocurrencies.id),
  quoteCryptoId: integer("quote_crypto_id").notNull().references(() => cryptocurrencies.id),
  symbol: varchar("symbol", { length: 20 }).notNull().unique(), // BTC/USDT
  isActive: boolean("is_active").notNull().default(true),
  minOrderSize: decimal("min_order_size", { precision: 20, scale: 8 }).notNull(),
  maxOrderSize: decimal("max_order_size", { precision: 20, scale: 8 }),
  priceDecimals: integer("price_decimals").notNull().default(2),
  amountDecimals: integer("amount_decimals").notNull().default(8),
  createdAt: timestamp("created_at").defaultNow(),
});

// Order book orders
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  pairId: integer("pair_id").notNull().references(() => tradingPairs.id),
  type: varchar("type", { length: 10 }).notNull(), // buy, sell
  orderType: varchar("order_type", { length: 10 }).notNull(), // market, limit
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  price: decimal("price", { precision: 20, scale: 8 }),
  filled: decimal("filled", { precision: 20, scale: 8 }).notNull().default("0"),
  status: varchar("status", { length: 20 }).notNull().default("active"), // active, filled, cancelled, partial
  isLiquidityOrder: boolean("is_liquidity_order").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Price history for charts
export const priceHistory = pgTable("price_history", {
  id: serial("id").primaryKey(),
  pairId: integer("pair_id").notNull().references(() => tradingPairs.id),
  price: decimal("price", { precision: 20, scale: 8 }).notNull(),
  volume: decimal("volume", { precision: 20, scale: 8 }).notNull().default("0"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Quick swap sessions (for anonymous users)
export const swapSessions = pgTable("swap_sessions", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull().unique(),
  fromCryptoId: integer("from_crypto_id").notNull().references(() => cryptocurrencies.id),
  toCryptoId: integer("to_crypto_id").notNull().references(() => cryptocurrencies.id),
  fromAmount: decimal("from_amount", { precision: 20, scale: 8 }).notNull(),
  toAmount: decimal("to_amount", { precision: 20, scale: 8 }).notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 20, scale: 8 }).notNull(),
  fee: decimal("fee", { precision: 20, scale: 8 }).notNull(),
  depositAddress: varchar("deposit_address", { length: 255 }).notNull(),
  withdrawalAddress: varchar("withdrawal_address", { length: 255 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  wallets: many(wallets),
  transactions: many(transactions),
  orders: many(orders),
}));

export const cryptocurrenciesRelations = relations(cryptocurrencies, ({ many }) => ({
  wallets: many(wallets),
  transactions: many(transactions),
  basePairs: many(tradingPairs, { relationName: "baseCrypto" }),
  quotePairs: many(tradingPairs, { relationName: "quoteCrypto" }),
}));

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, {
    fields: [wallets.userId],
    references: [users.id],
  }),
  cryptocurrency: one(cryptocurrencies, {
    fields: [wallets.cryptoId],
    references: [cryptocurrencies.id],
  }),
}));

export const tradingPairsRelations = relations(tradingPairs, ({ one, many }) => ({
  baseCrypto: one(cryptocurrencies, {
    fields: [tradingPairs.baseCryptoId],
    references: [cryptocurrencies.id],
    relationName: "baseCrypto",
  }),
  quoteCrypto: one(cryptocurrencies, {
    fields: [tradingPairs.quoteCryptoId],
    references: [cryptocurrencies.id],
    relationName: "quoteCrypto",
  }),
  orders: many(orders),
  priceHistory: many(priceHistory),
}));

export const ordersRelations = relations(orders, ({ one }) => ({
  user: one(users, {
    fields: [orders.userId],
    references: [users.id],
  }),
  pair: one(tradingPairs, {
    fields: [orders.pairId],
    references: [tradingPairs.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  cryptocurrency: one(cryptocurrencies, {
    fields: [transactions.cryptoId],
    references: [cryptocurrencies.id],
  }),
  type: one(transactionTypes, {
    fields: [transactions.typeId],
    references: [transactionTypes.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertCryptocurrencySchema = createInsertSchema(cryptocurrencies).omit({ id: true, createdAt: true });
export const insertWalletSchema = createInsertSchema(wallets).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTradingPairSchema = createInsertSchema(tradingPairs).omit({ id: true, createdAt: true });
export const insertSwapSessionSchema = createInsertSchema(swapSessions).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Cryptocurrency = typeof cryptocurrencies.$inferSelect;
export type InsertCryptocurrency = z.infer<typeof insertCryptocurrencySchema>;
export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type TradingPair = typeof tradingPairs.$inferSelect;
export type InsertTradingPair = z.infer<typeof insertTradingPairSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type SwapSession = typeof swapSessions.$inferSelect;
export type InsertSwapSession = z.infer<typeof insertSwapSessionSchema>;
export type PriceHistory = typeof priceHistory.$inferSelect;
